package oop.example;

import java.io.File;

/**
 *
 * @author VyVu
 */
public class Rose extends Flower implements Medicinal,Sceneable{

    @Override
    public void bloom() {
        //blooming
    }

    @Override
    public void grow() {
        //growing
    }

    @Override
    public boolean isMatchLocation(File fileName) {
        return true;
    }

    @Override
    public void drugProcess() {
        //processing
    }
    
}
