package oop.example;

import java.io.File;

/**
 *
 * @author VyVu
 */
public interface Sceneable {
    boolean isMatchLocation(File fileName);
}
