package oop.example;

import java.io.File;

/**
 *
 * @author VyVu
 */
public abstract class Flower extends Plant{
    public abstract void bloom();

    public Flower(File name) {
        
    }
    
}
