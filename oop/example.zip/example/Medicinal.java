package oop.example;

/**
 *
 * @author VyVu
 */
public interface Medicinal {
    public void drugProcess();
}
