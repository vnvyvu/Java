package oop.example;

/**
 *
 * @author VyVu
 */
public abstract class Plant {
    private String trunk,bough,leaf;
    public abstract void grow();
}
